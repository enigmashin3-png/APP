// 1) Seed a default user in MemStorage constructor (for dev/demo)
const defaultUser: User = {
  id: "user-1",
  username: "demo",
  email: "demo@example.com",
  name: "Demo User",
  level: "beginner",
  subscriptionStatus: "free",
  subscriptionTier: "free",
  customerId: null,
  trialEndsAt: null,
};
this.users.set(defaultUser.id, defaultUser);

// 2) Add helper methods inside MemStorage
async findUserByCustomerId(customerId: string): Promise<User | undefined> {
  return Array.from(this.users.values()).find(u => u.customerId === customerId);
}

async updateUser(id: string, updates: Partial<User>): Promise<User> {
  const existing = this.users.get(id);
  if (!existing) throw new Error("User not found");
  const updated = { ...existing, ...updates };
  this.users.set(id, updated);
  return updated;
}
