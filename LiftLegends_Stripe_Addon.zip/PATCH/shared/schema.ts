// Add these fields to your users table in shared/schema.ts

subscriptionStatus: text("subscription_status").default("free"), // free | trialing | active | past_due | canceled
subscriptionTier: text("subscription_tier").default("free"),     // free | pro
customerId: text("customer_id"),
trialEndsAt: timestamp("trial_ends_at"),
