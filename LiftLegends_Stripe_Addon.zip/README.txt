
Lift Legends — Stripe Subscriptions (7‑day trial) Addon
======================================================

This addon contains ready-to-drop files to integrate Stripe subscriptions with a 7‑day free trial into your existing Lift Legends (LiftTrackerAI) project.

Contents
--------
- REPLACE/server/index.ts        → replaces your existing server/index.ts (adds raw-body handling for Stripe webhook)
- REPLACE/server/routes.ts       → replaces your existing server/routes.ts (adds /api/me, checkout, portal, webhook; keeps your workout/exercise routes)
- PATCH/shared/schema.ts         → paste the snippet into your users table (adds subscription fields)
- PATCH/server/storage.ts        → paste the snippet to seed a demo user + add update helpers
- ADD/client/src/lib/useUser.ts  → new hook for current user
- ADD/client/src/components/ProGate.tsx → new component to gate premium features with a "Start 7‑Day Trial" CTA
- .env.example                   → environment variables template

How to apply (2–5 minutes)
--------------------------
1) Copy REPLACE/server/index.ts → into your project at server/index.ts (overwrite).
2) Copy REPLACE/server/routes.ts → into your project at server/routes.ts (overwrite).
3) Open shared/schema.ts and add the fields from PATCH/shared/schema.ts into your users table.
4) Open server/storage.ts and add the snippet from PATCH/server/storage.ts:
   - Seed default user "user-1"
   - Add findUserByCustomerId and updateUser helpers
5) Copy ADD/client/src/lib/useUser.ts and ADD/client/src/components/ProGate.tsx into your client folder.
6) Install dependencies:
   npm i stripe body-parser
7) Configure environment (use .env.example as a reference). On Render, set these in “Environment” and redeploy:
   - STRIPE_SECRET_KEY
   - STRIPE_PRICE_PRO
   - STRIPE_WEBHOOK_SECRET
   - APP_BASE_URL
8) Local test:
   npm run dev
   stripe listen --forward-to localhost:5000/api/stripe/webhook

Wrap any premium UI with <ProGate> ... </ProGate> to require Pro (active or trialing).
