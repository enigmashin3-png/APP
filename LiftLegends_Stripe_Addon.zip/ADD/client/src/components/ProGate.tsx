import { ReactNode } from "react";
import { useUser } from "@/lib/useUser";
import { Button } from "@/components/ui/button";

export function ProGate({ children }: { children: ReactNode }) {
  const { data } = useUser();
  const isPro =
    data?.subscriptionTier === "pro" &&
    (data?.subscriptionStatus === "active" || data?.subscriptionStatus === "trialing");

  if (isPro) return <>{children}</>;

  const goPremium = async () => {
    const res = await fetch("/api/stripe/checkout", { method: "POST" });
    const { url } = await res.json();
    window.location.href = url;
  };

  return (
    <div className="p-6 border rounded-lg text-center">
      <h3 className="font-semibold mb-2">Go Premium</h3>
      <p className="text-sm text-gray-500 mb-4">
        Start your <b>7-day free trial</b> to unlock AI coaching, leaderboards, ranks & badges, and advanced templates.
      </p>
      <Button className="bg-primary-600" onClick={goPremium}>Start 7-Day Trial</Button>
    </div>
  );
}
