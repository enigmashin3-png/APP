import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWorkoutSessionSchema, insertWorkoutSetSchema, insertWorkoutPlanSchema } from "@shared/schema";

// Stripe integration
import Stripe from "stripe";
import bodyParser from "body-parser";
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });

const CURRENT_USER_ID = "user-1"; // replace with real auth later

export async function registerRoutes(app: Express): Promise<Server> {
  // ---------- Exercises ----------
  app.get("/api/exercises", async (_req, res) => {
    try {
      const exercises = await storage.getExercises();
      res.json(exercises);
    } catch {
      res.status(500).json({ message: "Failed to fetch exercises" });
    }
  });

  app.get("/api/exercises/category/:category", async (req, res) => {
    try {
      const exercises = await storage.getExercisesByCategory(req.params.category);
      res.json(exercises);
    } catch {
      res.status(500).json({ message: "Failed to fetch exercises by category" });
    }
  });

  // ---------- Workout Plans ----------
  app.get("/api/workout-plans", async (req, res) => {
    try {
      const { userId, templates } = req.query;
      let plans;
      if (templates === "true") plans = await storage.getTemplateWorkoutPlans();
      else plans = await storage.getWorkoutPlans(userId as string);
      res.json(plans);
    } catch {
      res.status(500).json({ message: "Failed to fetch workout plans" });
    }
  });

  app.get("/api/workout-plans/:id", async (req, res) => {
    try {
      const plan = await storage.getWorkoutPlan(req.params.id);
      if (!plan) return res.status(404).json({ message: "Workout plan not found" });
      res.json(plan);
    } catch {
      res.status(500).json({ message: "Failed to fetch workout plan" });
    }
  });

  app.post("/api/workout-plans", async (req, res) => {
    try {
      const validation = insertWorkoutPlanSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid workout plan data", errors: validation.error.issues });
      }
      const plan = await storage.createWorkoutPlan(validation.data);
      res.status(201).json(plan);
    } catch {
      res.status(500).json({ message: "Failed to create workout plan" });
    }
  });

  app.patch("/api/workout-plans/:id", async (req, res) => {
    try {
      const planId = req.params.id;
      const updates = req.body;
      const updated = await storage.updateWorkoutPlan(planId, updates);
      res.json(updated);
    } catch (e: any) {
      res.status(500).json({ message: e.message || "Failed to update workout plan" });
    }
  });

  // ---------- Workout Sessions ----------
  app.get("/api/workout-sessions", async (req, res) => {
    try {
      const { userId } = req.query;
      if (!userId) return res.status(400).json({ message: "User ID is required" });
      const sessions = await storage.getWorkoutSessions(userId as string);
      res.json(sessions);
    } catch {
      res.status(500).json({ message: "Failed to fetch workout sessions" });
    }
  });

  app.get("/api/workout-sessions/active/:userId", async (req, res) => {
    try {
      const session = await storage.getActiveWorkoutSession(req.params.userId);
      res.json(session);
    } catch {
      res.status(500).json({ message: "Failed to fetch active workout session" });
    }
  });

  app.post("/api/workout-sessions", async (req, res) => {
    try {
      const validation = insertWorkoutSessionSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid workout session data", errors: validation.error.issues });
      }
      const session = await storage.createWorkoutSession(validation.data);
      res.status(201).json(session);
    } catch {
      res.status(500).json({ message: "Failed to create workout session" });
    }
  });

  app.patch("/api/workout-sessions/:id", async (req, res) => {
    try {
      const session = await storage.updateWorkoutSession(req.params.id, req.body);
      res.json(session);
    } catch {
      res.status(500).json({ message: "Failed to update workout session" });
    }
  });

  // ---------- Workout Sets ----------
  app.get("/api/workout-sets", async (req, res) => {
    try {
      const { sessionId, exerciseId, userId } = req.query;
      if (sessionId) {
        const sets = await storage.getWorkoutSets(sessionId as string);
        res.json(sets);
      } else if (exerciseId && userId) {
        const sets = await storage.getWorkoutSetsByExercise(exerciseId as string, userId as string);
        res.json(sets);
      } else {
        res.status(400).json({ message: "Either sessionId or (exerciseId + userId) is required" });
      }
    } catch {
      res.status(500).json({ message: "Failed to fetch workout sets" });
    }
  });

  app.post("/api/workout-sets", async (req, res) => {
    try {
      const validation = insertWorkoutSetSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid workout set data", errors: validation.error.issues });
      }
      const set = await storage.createWorkoutSet(validation.data);
      res.status(201).json(set);
    } catch {
      res.status(500).json({ message: "Failed to create workout set" });
    }
  });

  // ---------- User Stats ----------
  app.get("/api/users/:userId/stats", async (req, res) => {
    try {
      const stats = await storage.getUserStats(req.params.userId);
      res.json(stats);
    } catch {
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  // ---------- Auth-lite: current user ----------
  app.get("/api/me", async (_req, res) => {
    const user = await storage.getUser(CURRENT_USER_ID);
    res.json(user);
  });

  // ---------- Stripe Checkout (7-day trial) ----------
  app.post("/api/stripe/checkout", async (_req, res) => {
    try {
      const user = await storage.getUser(CURRENT_USER_ID);
      if (!user) return res.status(401).json({ message: "No user" });

      // Ensure Stripe customer
      let customerId = user.customerId;
      if (!customerId) {
        const customer = await stripe.customers.create({ email: user.email, name: user.name });
        customerId = customer.id;
        await storage.updateUser(user.id, { customerId });
      }

      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        success_url: `${process.env.APP_BASE_URL}/?upgrade=success`,
        cancel_url: `${process.env.APP_BASE_URL}/?upgrade=cancel`,
        customer: customerId,
        line_items: [{ price: process.env.STRIPE_PRICE_PRO!, quantity: 1 }],
        allow_promotion_codes: true,
        subscription_data: { trial_period_days: 7 },
      });

      res.json({ url: session.url });
    } catch (e: any) {
      res.status(400).json({ message: e.message || "Stripe checkout error" });
    }
  });

  // ---------- Stripe Billing Portal ----------
  app.post("/api/stripe/portal", async (_req, res) => {
    try {
      const user = await storage.getUser(CURRENT_USER_ID);
      if (!user?.customerId) return res.status(400).json({ message: "No customer" });

      const portal = await stripe.billingPortal.sessions.create({
        customer: user.customerId,
        return_url: `${process.env.APP_BASE_URL}/settings`,
      });
      res.json({ url: portal.url });
    } catch (e: any) {
      res.status(400).json({ message: e.message || "Stripe portal error" });
    }
  });

  // ---------- Stripe Webhook (raw body) ----------
  app.post("/api/stripe/webhook", bodyParser.raw({ type: "application/json" }), async (req, res) => {
    const sig = req.headers["stripe-signature"];
    let event;
    try {
      event = stripe.webhooks.constructEvent(req.body, sig!, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err: any) {
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "customer.subscription.created" || event.type === "customer.subscription.updated") {
      const sub = event.data.object as Stripe.Subscription;
      const user = await storage.findUserByCustomerId(sub.customer as string);
      if (user) {
        const isPro = sub.status === "active" || sub.status === "trialing";
        await storage.updateUser(user.id, {
          subscriptionStatus: sub.status as any,
          subscriptionTier: isPro ? "pro" : "free",
          trialEndsAt: sub.trial_end ? new Date(sub.trial_end * 1000) : null,
        });
      }
    }

    if (event.type === "customer.subscription.deleted") {
      const sub = event.data.object as Stripe.Subscription;
      const user = await storage.findUserByCustomerId(sub.customer as string);
      if (user) {
        await storage.updateUser(user.id, {
          subscriptionStatus: "canceled",
          subscriptionTier: "free",
          trialEndsAt: null,
        });
      }
    }

    res.json({ received: true });
  });

  const httpServer = createServer(app);
  return httpServer;
}
